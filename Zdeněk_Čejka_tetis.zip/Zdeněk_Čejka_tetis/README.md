tetris in python even though i can't find a single reason why any game should be written in python

controls are with WSAD,space and enter. in the main menu navigation is with W and S and enter is to select.
 in the game space is for rotation and A,D for moving block to side 